#!/bin/bash

python align.py $@ 1
