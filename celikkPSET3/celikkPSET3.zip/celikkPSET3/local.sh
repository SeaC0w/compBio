#!/bin/bash

python align.py $@ 0
