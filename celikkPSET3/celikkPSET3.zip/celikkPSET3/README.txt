Computational Biology Problem Set 3 by Kerim Celik (1/25/2018)
==============================================================

My alignment code (align.py) is written in Python3, and therefore requires no compiling.
The code requires the following packages: sys, math, numpy, BioPython.
The xcelalign.py program also requires the xlsxwriter package for writing to excel.

No known bugs exist.

The alignment algorithms both print their answers to the terminal.
Since the two aligned strings are printed sequentially, if the strings you are
aligning are long, they will not be visually aligned in the terminal. For convenience,
the alignment programs print "V" and "W" above the associated aligned string.
